package com.example.trucking

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.trucking.ui.theme.TruckingTheme

data class Voyage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val number: Int,
    val departure: String,
    val arrival: String,
    val cargo: String,
    val loadingPrice: Double,
    val voyageExpenses: Double
) {
    val netIncome: Double get() = loadingPrice - voyageExpenses
}

enum class ExpenseType { MAINTENANCE, OTHER }
data class Expense(
    val id: String = java.util.UUID.randomUUID().toString(),
    val type: ExpenseType,
    val amount: Double,
    val date: String,
    val note: String = ""
)

data class AppState(
    val voyages: MutableList<Voyage> = mutableListOf(),
    val maintenance: MutableList<Expense> = mutableListOf(),
    val other: MutableList<Expense> = mutableListOf()
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TruckingTheme {
                val nav = rememberNavController()
                val state = remember { mutableStateOf(AppState()) }

                Scaffold(
                    topBar = { SmallTopAppBar(title = { Text("Trucking App") }) },
                    floatingActionButton = {}
                ) { padding ->
                    NavHost(
                        navController = nav,
                        startDestination = "home",
                        modifier = Modifier.padding(padding)
                    ) {
                        composable("home") {
                            HomeScreen(
                                state = state.value,
                                onOpenVoyages = { nav.navigate("voyages") },
                                onOpenMaintenance = { nav.navigate("maintenance") },
                                onOpenOther = { nav.navigate("other") },
                                onOpenAnalysis = { nav.navigate("analysis") }
                            )
                        }
                        composable("voyages") {
                            VoyageListScreen(
                                state = state.value,
                                onBack = { nav.popBackStack() },
                                onAdd = { nav.navigate("voyage_form") }
                            )
                        }
                        composable("voyage_form") {
                            VoyageFormScreen(
                                onSave = { v ->
                                    state.value.voyages.add(v)
                                    nav.popBackStack()
                                },
                                onCancel = { nav.popBackStack() }
                            )
                        }
                        composable("maintenance") {
                            ExpenseListScreen(
                                title = "Maintenance",
                                expenses = state.value.maintenance,
                                onAdd = { nav.navigate("expense_form/MAINTENANCE") },
                                onBack = { nav.popBackStack() }
                            )
                        }
                        composable("other") {
                            ExpenseListScreen(
                                title = "Other Expenses",
                                expenses = state.value.other,
                                onAdd = { nav.navigate("expense_form/OTHER") },
                                onBack = { nav.popBackStack() }
                            )
                        }
                        composable(
                            route = "expense_form/{type}",
                            arguments = listOf(navArgument("type") { type = NavType.StringType })
                        ) { backStackEntry ->
                            val typeStr = backStackEntry.arguments?.getString("type") ?: "OTHER"
                            val type = if (typeStr == "MAINTENANCE") ExpenseType.MAINTENANCE else ExpenseType.OTHER
                            ExpenseFormScreen(
                                type = type,
                                onSave = { e ->
                                    when (type) {
                                        ExpenseType.MAINTENANCE -> state.value.maintenance.add(e)
                                        ExpenseType.OTHER -> state.value.other.add(e)
                                    }
                                    nav.popBackStack()
                                },
                                onCancel = { nav.popBackStack() }
                            )
                        }
                        composable("analysis") {
                            AnalysisScreen(state = state.value, onBack = { nav.popBackStack() })
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(
    state: AppState,
    onOpenVoyages: () -> Unit,
    onOpenMaintenance: () -> Unit,
    onOpenOther: () -> Unit,
    onOpenAnalysis: () -> Unit
) {
    val totalRevenue = state.voyages.sumOf { it.loadingPrice }
    val totalVoyageExpenses = state.voyages.sumOf { it.voyageExpenses }
    val totalOther = state.other.sumOf { it.amount } + state.maintenance.sumOf { it.amount }
    val net = totalRevenue - totalVoyageExpenses - totalOther

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Dashboard", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
        item {
            StatRow("Total Revenue", totalRevenue)
        }
        item {
            StatRow("Voyage Expenses", totalVoyageExpenses)
        }
        item {
            StatRow("Maintenance + Other", totalOther)
        }
        item {
            StatRow("Net (All-time)", net)
        }
        item { ActionButton("Voyages", onOpenVoyages) }
        item { ActionButton("Maintenance", onOpenMaintenance) }
        item { ActionButton("Other Expenses", onOpenOther) }
        item { ActionButton("Analysis", onOpenAnalysis) }
    }
}

@Composable private fun StatRow(label: String, value: Double) {
    Surface(tonalElevation = 2.dp, shape = MaterialTheme.shapes.medium) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, style = MaterialTheme.typography.titleMedium)
            Text("ETB %.2f".format(value), fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable private fun ActionButton(text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(52.dp)
    ) {
        Text(text)
    }
}

@Composable
fun VoyageListScreen(state: AppState, onBack: () -> Unit, onAdd: () -> Unit) {
    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = { Text("Voyages") },
                navigationIcon = {
                    TextButton(onClick = onBack) { Text("Back") }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onAdd) { Text("+") }
        }
    ) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(state.voyages) { v ->
                Surface(tonalElevation = 2.dp, shape = MaterialTheme.shapes.medium) {
                    Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                        Text("Voyage #${v.number} • ${v.departure} → ${v.arrival}", fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(4.dp))
                        Text("Cargo: ${v.cargo}")
                        Spacer(Modifier.height(8.dp))
                        Text("Loading Price: ETB %.2f".format(v.loadingPrice))
                        Text("Expenses: ETB %.2f".format(v.voyageExpenses))
                        Text("Net: ETB %.2f".format(v.netIncome), fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

@Composable
fun VoyageFormScreen(onSave: (Voyage) -> Unit, onCancel: () -> Unit) {
    var number by remember { mutableStateOf("") }
    var departure by remember { mutableStateOf("") }
    var arrival by remember { mutableStateOf("") }
    var cargo by remember { mutableStateOf("") }
    var loadingPrice by remember { mutableStateOf("") }
    var voyageExpenses by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = { Text("New Voyage") },
                navigationIcon = { TextButton(onClick = onCancel) { Text("Cancel") } }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(value = number, onValueChange = { number = it.filter { c -> c.isDigit() } }, label = { Text("Voyage Number") })
            OutlinedTextField(value = departure, onValueChange = { departure = it }, label = { Text("Departure") })
            OutlinedTextField(value = arrival, onValueChange = { arrival = it }, label = { Text("Arrival") })
            OutlinedTextField(value = cargo, onValueChange = { cargo = it }, label = { Text("Cargo / Notes") })
            OutlinedTextField(value = loadingPrice, onValueChange = { loadingPrice = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("Loading Price (ETB)") })
            OutlinedTextField(value = voyageExpenses, onValueChange = { voyageExpenses = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("Voyage Expenses (ETB)") })

            Button(
                onClick = {
                    val v = Voyage(
                        number = number.toIntOrNull() ?: 1,
                        departure = departure.ifBlank { "N/A" },
                        arrival = arrival.ifBlank { "N/A" },
                        cargo = cargo.ifBlank { "-" },
                        loadingPrice = loadingPrice.toDoubleOrNull() ?: 0.0,
                        voyageExpenses = voyageExpenses.toDoubleOrNull() ?: 0.0
                    )
                    onSave(v)
                },
                enabled = number.isNotBlank()
            ) {
                Text("Save Voyage")
            }
        }
    }
}

@Composable
fun ExpenseListScreen(title: String, expenses: List<Expense>, onAdd: () -> Unit, onBack: () -> Unit) {
    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = { Text(title) },
                navigationIcon = { TextButton(onClick = onBack) { Text("Back") } }
            )
        },
        floatingActionButton = { FloatingActionButton(onClick = onAdd) { Text("+") } }
    ) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(expenses) { e ->
                Surface(tonalElevation = 2.dp, shape = MaterialTheme.shapes.medium) {
                    Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                        Text("ETB %.2f".format(e.amount), fontWeight = FontWeight.SemiBold)
                        Text("Date: ${e.date}")
                        if (e.note.isNotBlank()) Text(e.note)
                    }
                }
            }
        }
    }
}

@Composable
fun ExpenseFormScreen(type: ExpenseType, onSave: (Expense) -> Unit, onCancel: () -> Unit) {
    var amount by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = { Text("Add ${type.name.lowercase().replaceFirstChar { it.uppercase() }}") },
                navigationIcon = { TextButton(onClick = onCancel) { Text("Cancel") } }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(value = amount, onValueChange = { amount = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("Amount (ETB)") })
            OutlinedTextField(value = date, onValueChange = { date = it }, label = { Text("Date") })
            OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Note (optional)") })

            Button(
                onClick = {
                    val e = Expense(
                        type = type,
                        amount = amount.toDoubleOrNull() ?: 0.0,
                        date = date.ifBlank { "N/A" },
                        note = note
                    )
                    onSave(e)
                },
                enabled = amount.isNotBlank()
            ) { Text("Save") }
        }
    }
}

@Composable
fun AnalysisScreen(state: AppState, onBack: () -> Unit) {
    val totalRevenue = state.voyages.sumOf { it.loadingPrice }
    val voyageExpenses = state.voyages.sumOf { it.voyageExpenses }
    val other = state.other.sumOf { it.amount }
    val maintenance = state.maintenance.sumOf { it.amount }
    val net = totalRevenue - voyageExpenses - other - maintenance

    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = { Text("Analysis (All-time)") },
                navigationIcon = { TextButton(onClick = onBack) { Text("Back") } }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Simple Totals", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            StatRow("Revenue", totalRevenue)
            StatRow("Voyage Expenses", voyageExpenses)
            StatRow("Maintenance", maintenance)
            StatRow("Other", other)
            Divider()
            StatRow("Net", net)
            Spacer(Modifier.height(16.dp))
            Text("Note: This starter app stores data in memory only (for the first build). We will add local storage, GPS, and per-truck tracking in the next iteration.", style = MaterialTheme.typography.bodySmall)
        }
    }
}
